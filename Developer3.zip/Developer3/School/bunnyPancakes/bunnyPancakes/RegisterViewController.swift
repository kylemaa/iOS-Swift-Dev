//
//  RegisterViewController.swift
//  bunnyPancakes
//
//  Created by Justin Stokes on 11/20/18.
//  Copyright © 2018 Justin Stokes. All rights reserved.
//

import Foundation
import UIKit
import FirebaseAuth
import Firebase

class RegisterViewController: UIViewController {

    @IBOutlet weak var PasswordText: UITextField!
    @IBOutlet weak var UsernameText: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func PlayBtnPress(_ sender: UIButton) {
        Auth.auth().createUser(withEmail: UsernameText.text!, password: PasswordText.text!) {
            (user, error) in
            if error != nil {
                print(error!)}
            else{
                print("Registration Successful")
                self.performSegue(withIdentifier: "RegisterToMM", sender: self)
            }
        }
    }
    
    @IBAction func ExitBtnPress(_ sender: UIButton) {
        performSegue(withIdentifier: "RegisterExitBtn", sender: self)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
