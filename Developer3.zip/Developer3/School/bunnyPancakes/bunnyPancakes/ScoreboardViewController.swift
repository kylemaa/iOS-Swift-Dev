//
//  ScoreboardViewController.swift
//  bunnyPancakes
//
//  Created by Justin Stokes on 11/20/18.
//  Copyright © 2018 Justin Stokes. All rights reserved.
//

import UIKit
import FirebaseDatabase
import Firebase

class ScoreboardViewController: UIViewController, UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return postData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = TableView.dequeueReusableCell(withIdentifier: "PostCell")
        cell?.textLabel?.text = postData[indexPath.row]
        return cell!
    }
    
    var rootref:DatabaseReference?
    var readref:DatabaseReference?
    var databaseHandle: DatabaseHandle?
    var postData = [String]()
    override func viewDidLoad() {
        super.viewDidLoad()
        TableView.delegate = self
        TableView.dataSource = self
        rootref = Database.database().reference()
        readref = Database.database().reference()
        // Do any additional setup after loading the view.
        databaseHandle = readref?.child("User Name").observe(.childAdded, with: {(snapshot) in
            let post = snapshot.value as?String
            if let actualPost = post {
                self.postData.append(actualPost)
                self.TableView.reloadData()
            }
        })
    }
    @IBOutlet weak var YourScore: UITextField!
    @IBOutlet weak var TableView: UITableView!
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        //Dispose of any resources that can be recreated.
    }
    @IBAction func AddScoreandShow(_ sender: Any) {
        let userdefaults = Foundation.UserDefaults.standard
        let value = userdefaults.string(forKey: "Key")
        rootref?.child("User Name").childByAutoId().setValue(value)
        print("Sending new score to database")
        presentingViewController?.dismiss(animated: true, completion: nil)
    }
    override func viewWillAppear(_ animated: Bool) {
        let userdefaults = Foundation.UserDefaults.standard
        let value = userdefaults.string(forKey: "Key")
        YourScore.text = value
    }

    
    @IBAction func MainMenuPress(_ sender: UIButton) {
        performSegue(withIdentifier: "ScoreToMM", sender: self)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
