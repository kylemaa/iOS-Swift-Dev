//
//  GameScene.swift
//  bunnyPancakes
//
//  Created by Justin Stokes on 9/22/18.
//  Copyright © 2018 Justin Stokes. All rights reserved.
//

import SpriteKit
import GameplayKit
import CloudKit
import Firebase
import FirebaseDatabase



class GameScene: SKScene, SKPhysicsContactDelegate {

    
    
    
    var score = 0 {
        didSet {
            scoreLabel.text = "Score: \(score)"
            let savedString = scoreLabel.text
            let userDefaults = Foundation.UserDefaults.standard
            userDefaults.set(savedString, forKey: "Key")
        }
    }
    
    var strikes = 0 {
        didSet{
            strikeLabel.text = "Strikes: \(strikes)"
        }
    }
   
    var kitty: SKSpriteNode!
    var bunny: SKSpriteNode!
    var table: SKSpriteNode!
    var droppedItem: SKSpriteNode!
    var scoreLabel: SKLabelNode!
    var strikeLabel: SKLabelNode!
    
    var itemsToDrop = ["Pancake", "Milkshake"]
    
    var foodTimer: Timer!
    
    
    
    override func didMove(to view: SKView) {
        
      
        scoreLabel = SKLabelNode(fontNamed: "ChalkDuster")
        scoreLabel.text = "Score: 0"
        scoreLabel.position = CGPoint(x: -200, y: 500)
        addChild(scoreLabel)
        
        strikeLabel = SKLabelNode(fontNamed: "ChalkDuster")
        strikeLabel.text = "Strikes: 0"
        strikeLabel.position = CGPoint(x: -200, y: 450)
        addChild(strikeLabel)
        
        kitty = SKSpriteNode(imageNamed: "Kitty")
        kitty.position = CGPoint(x: -250, y: -300)
        kitty.size.width = 300
        kitty.size.height = 200
        kitty.physicsBody = SKPhysicsBody(rectangleOf: kitty.size)
        kitty.physicsBody?.isDynamic = false
        kitty.name = "kitty"
        self.addChild(kitty)
        
        bunny = SKSpriteNode(imageNamed: "Bunny")
        bunny.position = CGPoint(x: 250, y: -300)
        bunny.size.width = 300
        bunny.size.height = 200
        bunny.physicsBody = SKPhysicsBody(rectangleOf: bunny.size)
        bunny.physicsBody?.isDynamic = false
        bunny.name = "bunny"
        self.addChild(bunny)
        
        table = SKSpriteNode(imageNamed: "Table")
        table.position = CGPoint(x: 0, y: -500)
        table.size.width = 650
        table.size.height = 200
        table.physicsBody = SKPhysicsBody(rectangleOf: table.size)
        table.physicsBody?.isDynamic = false
        table.name = "table"
        self.addChild(table)
        
        foodTimer = Timer.scheduledTimer(timeInterval: 3, target: self, selector: #selector(dropFood), userInfo: nil, repeats: true)
        
        physicsWorld.contactDelegate = self
        self.physicsWorld.gravity = CGVector(dx: 0, dy: -6.0)
        
        
    }
    
    @objc func dropFood()  {
        itemsToDrop = GKRandomSource.sharedRandom().arrayByShufflingObjects(in: itemsToDrop) as! [String]
        droppedItem = SKSpriteNode(imageNamed: itemsToDrop[0])
        droppedItem.position = CGPoint(x: 0, y: 500/*self.frame.size.height + droppedItem.size.height*/)
        droppedItem.size.width = 100
        droppedItem.size.height = 100
        
        droppedItem.physicsBody = SKPhysicsBody(rectangleOf: droppedItem.size)
        droppedItem.physicsBody?.isDynamic = true
        droppedItem.name = itemsToDrop[0]
        //print(droppedItem.name!) //debug print statement
        droppedItem.physicsBody!.contactTestBitMask = droppedItem.physicsBody!.collisionBitMask
        self.addChild(droppedItem)
       
    }
    
    func didBegin(_ contact: SKPhysicsContact) {
        if contact.bodyA.node?.name == "table" { //check for table contact
            print(contact.bodyA.node!.name!)
            disappear(item: contact.bodyB.node!)
            strikes = strikes + 1
            if(strikes == 3){
                strikes = 0
                self.removeFromParent()
                self.view?.presentScene(nil)
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "GameOver"), object: nil)
            
            }
        } else if contact.bodyA.node?.name == "bunny" { //check for bunny contact
            if contact.bodyB.node?.name == "Pancake" {
                //add to score
                score = score + 100
                disappear(item: contact.bodyB.node!)
            } else {
                strikes = strikes + 1
                disappear(item: contact.bodyB.node!)
            }
        } else { //kitty contact
            if contact.bodyB.node?.name == "Milkshake" {
                score = score + 100
                disappear(item: contact.bodyB.node!)
            } else {
                strikes = strikes + 1
                disappear(item: contact.bodyB.node!)
            }
        }
        
    }
    
    func disappear(item: SKNode) {
        item.removeFromParent()
    }
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        for touch in touches {
            
            let touchLocation = touch.location(in: self)
            droppedItem.position.x = touchLocation.x
            droppedItem.position.y = touchLocation.y
        }
    }
    
}
