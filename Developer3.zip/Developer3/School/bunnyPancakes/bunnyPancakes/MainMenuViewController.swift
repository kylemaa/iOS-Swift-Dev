//
//  MainMenuViewController.swift
//  bunnyPancakes
//
//  Created by Justin Stokes on 11/20/18.
//  Copyright © 2018 Justin Stokes. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
class MainMenuViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func NewGameBtnPress(_ sender: UIButton) {
        performSegue(withIdentifier: "NewGameBtn", sender: self)
    }
    
    @IBAction func StoreBtnPress(_ sender: UIButton) {
        performSegue(withIdentifier: "StoreBtn", sender: self)
    }
    
    @IBAction func ScoreboardBtnPress(_ sender: UIButton) {
        performSegue(withIdentifier: "ScoreboardBtn", sender: self)
    }
    
    @IBAction func HowtoBtnPress(_ sender: UIButton) {
        performSegue(withIdentifier: "HowToBtn", sender: self)
    }
    
    @IBAction func OptionBtnPress(_ sender: UIButton) {
        performSegue(withIdentifier: "OptionBtn", sender: self)
    }
    @IBAction func LogoutBtnPress(_ sender: UIButton) {
        do
        {try Auth.auth().signOut()}
        catch{
            print("There was a problem signing out of your account")
        }
        guard(navigationController?.popToRootViewController(animated: true)) != nil
            else{
                print("Logged out successful")
                performSegue(withIdentifier: "LogoutBtn", sender: self)
                return
        }
    }
    @IBAction func CreditBtnPress(_ sender: Any) {
        performSegue(withIdentifier: "CreditBtn", sender: self)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
