//
//  StoreViewController.swift
//  bunnyPancakes
//
//  Created by Justin Stokes on 11/20/18.
//  Copyright © 2018 Justin Stokes. All rights reserved.
//

import UIKit

class StoreViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func MainMenuPress(_ sender: UIButton) {
        performSegue(withIdentifier: "StoreToMM", sender: self)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
